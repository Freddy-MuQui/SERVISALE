package cl.duoc.basico.utils

class RecursosNativos{
}